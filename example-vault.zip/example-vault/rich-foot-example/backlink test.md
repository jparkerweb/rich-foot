# Backlink Test

When the `rich-foot` plugin is enabled, this note will display a *backlink* to [[🦶 Rich Foot]] because it links to this note.