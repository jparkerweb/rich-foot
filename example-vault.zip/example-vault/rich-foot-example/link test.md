---
links:
  - "[[one]]"
---

# Link Test

When the `rich-foot` plugin is enabled, this note will display a *backlink* to [[🦶 Rich Foot]] because it links to this note.

one, two, three

I wonder where this goes: [[no rich-feet here#This some some section that I want an outlink to go to]]

some text^[ more text [[three]].]
	