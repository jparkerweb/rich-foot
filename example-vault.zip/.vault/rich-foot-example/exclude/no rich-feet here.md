### This note is a direct child of a folder defined in the settings `Excluded Folders` section, and will not display the [[🦶 Rich Foot]] plugin in the note's footer.

#### This some some section that I want an outlink to go to
