# 2️⃣ two


>[!infobox]
> # Name
> ![[stuffed-links.png|cover small]]
> ###### Info
> | Type |  -- |
> | ---- | ---- |
> | Location | x |
> | Class | x |
> | Race | x |
> | Deity | x |
> | Gender| x |
> | Age | x |
> | Birth | x |
> | Death | x |
> | Height | x M|


### Relations


### Personality & Looks

#### Misinformation/Lies
