---
links:
  - "[[two]]"
---

# 1️⃣ one
