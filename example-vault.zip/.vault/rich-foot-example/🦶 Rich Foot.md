---
banner-shuffle: images
links:
  - "[[link test]]"
content-start: "333"
---

# 🦶 Rich Foot
🐙 [GitHub](https://github.com/jparkerweb/rich-foot)
📝 [Release Notes Generator](https://jparkerweb.github.io/release-notes/)

## Float me {.float-right}

Rich Foot is an Obsidian plugin that enhances the footer of your notes by adding backlink tags and created/modified dates.


[[no rich-feet here]]


